This directory contains the expected output png files.
The mortar with 1 pixel (expected_mortar1.png)
The mortar with 2 pixels (expected_mortar2.png)
You must match the expected output within 500 pixels to be considered correct for both files.