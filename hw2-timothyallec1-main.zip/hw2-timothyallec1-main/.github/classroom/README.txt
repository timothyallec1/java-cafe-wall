The file autograding.json is NOT being used because the GitHub workflow step education/autograding@v1 did not run
the gradle tests correctly.  A manual workflow is being used instead - in the future if the autograding feature
can be implemented properly then use of autograding.json should be revisited.