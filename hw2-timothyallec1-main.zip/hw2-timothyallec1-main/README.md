# HW2
starter code for homework 2 - cafe wall